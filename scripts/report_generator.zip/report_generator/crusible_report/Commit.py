

class Commit:
    def __init__(self, cl, date, reviewKey):
        self.cl = cl
        self.date = date
        self.author = str()
        self.reviewKey = reviewKey
        self.reviewState = str()
        self.reviewers = list()
        self.files = list()
        self.comments = list()
        self.timeSpent = str()