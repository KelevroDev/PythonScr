from utility.FileSystem import FileSystem as FS
from utility.htmlCtx import *
from datetime import datetime
from crusible_report.Commit import Commit
from crusible_report.Crucible import Crucible
import re


class CrucibleReport:
    def __init__(self, logOutput):
        self.p4ChangeFile = str()
        self.dateFrom = str()
        self.dateTo = str()
        self.url = str()
        self.user = str()
        self.password = str()

        self.log = logOutput
        self.logNormal = self.log.addSimpleMessageSignal.emit
        self.logInc = self.log.incProgressSignal.emit
        self.endCall = None

        self.commits = list()
        self.cru = None


    def start(self):
        self.commits = list()
        self.getCommits()

        for x in self.commits:
            print("%s\t%s\t%s" % (x.cl, x.date, x.reviewKey))

        self.cru = Crucible(self.url, self.user, self.password)
        print(self.cru)


        if self.endCall:
            self.endCall()


    def getCommits(self):
        startDate = datetime.strptime(self.dateFrom, "%Y/%m/%d")
        endDate = datetime.strptime(self.dateTo, "%Y/%m/%d")

        with open(self.p4ChangeFile, "r") as file:
            ctx = file.read()
            commitInfo = ctx.split("/-1.1.1**")

            for info in commitInfo:
                cls = re.findall("Change (\d+) on", info)

                if len(cls):
                    dateStr = re.findall("on ([\w\/]+) by", info)

                    if len(dateStr):
                        cl = cls[0]
                        date = datetime.strptime(dateStr[0], "%Y/%m/%d")
                        reviewKey = str()

                        if date >= startDate and date <= endDate:
                            reviewKeys = re.findall("review (CR-HTOYOTA-[\w]+)", info)

                            if len(reviewKeys):
                                reviewKey = reviewKeys[0]

                            self.commits.append(Commit(cl, date, reviewKey))
