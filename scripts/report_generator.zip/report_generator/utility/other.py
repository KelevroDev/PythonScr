import traceback

def traceErr():
        return traceback.format_exc().replace("\n", "<br>")