__author__ = 'DMorozov'

from PyQt5 import QtCore, QtGui, QtWidgets
from datetime import datetime

class LogWidget(QtWidgets.QFrame):
    setProgressMaxSignal = QtCore.pyqtSignal(int)
    setProgressValueSignal = QtCore.pyqtSignal(int)
    addSimpleMessageSignal = QtCore.pyqtSignal(str)
    addProgressMessageSignal = QtCore.pyqtSignal(str)
    incProgressSignal = QtCore.pyqtSignal()
    setHiddenSignal = QtCore.pyqtSignal(bool)
    setMaximizedSignal = QtCore.pyqtSignal(bool)
    operationFinishedSignal = QtCore.pyqtSignal()

    stdOutputSignal = QtCore.pyqtSignal(str)


    def __init__(self, parent):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setupUi(self)
        self.isMaximized = True
        self.PROGRESS_BAR.setHidden(True)
        self.setFrameShape(QtWidgets.QFrame.Box)

    def setupUi(self, LOG_WIDGET):
        LOG_WIDGET.setObjectName("LOG_WIDGET")
        LOG_WIDGET.resize(640, 300)
        self.verticalLayout = QtWidgets.QVBoxLayout(LOG_WIDGET)
        self.verticalLayout.setContentsMargins(6, 6, 6, 6)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.LBL_TITLE = QtWidgets.QLabel(LOG_WIDGET)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.LBL_TITLE.sizePolicy().hasHeightForWidth())
        self.LBL_TITLE.setSizePolicy(sizePolicy)
        self.LBL_TITLE.setMinimumSize(QtCore.QSize(0, 20))
        font = QtGui.QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.LBL_TITLE.setFont(font)
        self.LBL_TITLE.setStyleSheet("color: rgb(0, 255, 255);\n"
"background-color: rgb(5, 23, 85);")
        self.LBL_TITLE.setAlignment(QtCore.Qt.AlignCenter)
        self.LBL_TITLE.setObjectName("LBL_TITLE")
        self.verticalLayout.addWidget(self.LBL_TITLE)
        self.BROWSER = QtWidgets.QTextBrowser(LOG_WIDGET)
        self.BROWSER.setStyleSheet("border: 4px solid rgb(5, 23, 85);\n"
"background-color: qlineargradient(spread:pad, x1:1, y1:0, x2:0, y2:0, stop:0 rgba(34, 0, 72, 113), stop:1 rgba(62, 198, 255, 97));")
        self.BROWSER.setOpenExternalLinks(True)
        self.BROWSER.setObjectName("BROWSER")
        self.verticalLayout.addWidget(self.BROWSER)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setContentsMargins(6, 6, 6, 6)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.PROGRESS_BAR = QtWidgets.QProgressBar(LOG_WIDGET)
        self.PROGRESS_BAR.setProperty("value", 0)
        self.PROGRESS_BAR.setObjectName("PROGRESS_BAR")
        self.horizontalLayout.addWidget(self.PROGRESS_BAR)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.BTN_COPY = QtWidgets.QPushButton(LOG_WIDGET)
        self.BTN_COPY.setObjectName("BTN_COPY")
        self.horizontalLayout.addWidget(self.BTN_COPY)
        self.BTN_CLEAR = QtWidgets.QPushButton(LOG_WIDGET)
        self.BTN_CLEAR.setObjectName("BTN_CLEAR")
        self.horizontalLayout.addWidget(self.BTN_CLEAR)
        self.BTN_MINIMIZE_MAXIMIZE = QtWidgets.QPushButton(LOG_WIDGET)
        self.BTN_MINIMIZE_MAXIMIZE.setObjectName("BTN_MINIMIZE_MAXIMIZE")
        self.horizontalLayout.addWidget(self.BTN_MINIMIZE_MAXIMIZE)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(LOG_WIDGET)
        QtCore.QMetaObject.connectSlotsByName(LOG_WIDGET)

    def retranslateUi(self, LOG_WIDGET):
        _translate = QtCore.QCoreApplication.translate
        LOG_WIDGET.setWindowTitle(_translate("LOG_WIDGET", "Process log"))
        self.LBL_TITLE.setText(_translate("LOG_WIDGET", "Process log"))
        self.BTN_COPY.setText(_translate("LOG_WIDGET", "Copy"))
        self.BTN_CLEAR.setText(_translate("LOG_WIDGET", "Clear"))
        self.BTN_MINIMIZE_MAXIMIZE.setText(_translate("LOG_WIDGET", "Minimize"))
    #*******************************************************************************************************************
        self.BTN_CLEAR.pressed.connect(self.BROWSER.clear)
        self.BTN_COPY.pressed.connect(self.copy2clipboard)
        self.BTN_MINIMIZE_MAXIMIZE.pressed.connect(self.minimizeOrMaximize)
        self.setProgressMaxSignal.connect(self.PROGRESS_BAR.setMaximum)
        self.setProgressValueSignal.connect(self.PROGRESS_BAR.setValue)
        self.addSimpleMessageSignal.connect(self.addSimpleMessage)
        self.addProgressMessageSignal.connect(self.addProgressMessage)
        self.incProgressSignal.connect(self.incProgress)
        self.setHiddenSignal.connect(self.setHidden)
        self.setMaximizedSignal.connect(self.setMaximized)
        self.stdOutputSignal.connect(self.BROWSER.append)


    def addProgressMessage(self, ctx):
        self.BROWSER.append(self.timeNow() + ctx)
        self.incProgress()


    def addSimpleMessage(self, ctx):
        self.BROWSER.append(self.timeNow() + ctx)


    def incProgress(self):
        if self.PROGRESS_BAR.value() == 0:
            self.setMaximized(True)
            self.PROGRESS_BAR.setHidden(False)

        if self.PROGRESS_BAR.value() < self.PROGRESS_BAR.maximum():
            self.PROGRESS_BAR.setValue(self.PROGRESS_BAR.value() + 1)

        if self.PROGRESS_BAR.value() == self.PROGRESS_BAR.maximum():
            self.operationFinishedSignal.emit()
            self.PROGRESS_BAR.setHidden(True)


    def setMaximized(self, boolValue):
        if boolValue:
            self.maximize()
        else:
            self.minimize()


    def copy2clipboard(self):
        self.BROWSER.selectAll()
        self.BROWSER.copy()


    def minimize(self):
        self.LBL_TITLE.setHidden(True)
        self.BTN_CLEAR.setHidden(True)
        self.BTN_COPY.setHidden(True)
        self.BROWSER.setHidden(True)
        self.isMaximized = False
        self.BTN_MINIMIZE_MAXIMIZE.setText("Show log")


    def maximize(self):
        self.LBL_TITLE.setHidden(False)
        self.BTN_CLEAR.setHidden(False)
        self.BTN_COPY.setHidden(False)
        self.BROWSER.setHidden(False)
        self.isMaximized = True
        self.BTN_MINIMIZE_MAXIMIZE.setText("Hide log")


    def minimizeOrMaximize(self):
        if self.isMaximized:
            self.minimize()
        else:
            self.maximize()


    def timeNow(self):
        return datetime.now().strftime("[%H:%M:%S] ")


