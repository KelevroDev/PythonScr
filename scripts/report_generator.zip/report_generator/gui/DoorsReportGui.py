from PyQt5 import QtCore, QtGui, QtWidgets
from gui.LogWidget import LogWidget
from utility.FileSystem import FileSystem as FS
from utility.NiceData import NiceData as ND
from utility.htmlCtx import *
from threading import Thread
from doors_report.DoorsReport import DoorsReport



class DoorsReportGui(QtWidgets.QWidget):
    def __init__(self, parent = None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setupUi(self)
        self.reportObj = DoorsReport(self.LOG_WIDGET)
        self.loadSettings()


    def setupUi(self, DOORS_REPORT):
        DOORS_REPORT.setObjectName("DOORS_REPORT")
        DOORS_REPORT.resize(1200, 800)
        self.verticalLayout = QtWidgets.QVBoxLayout(DOORS_REPORT)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.TITLE = QtWidgets.QLabel(DOORS_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.TITLE.sizePolicy().hasHeightForWidth())
        self.TITLE.setSizePolicy(sizePolicy)
        self.TITLE.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setWeight(75)
        self.TITLE.setFont(font)
        self.TITLE.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(162, 162, 162, 255));\n"
"color: rgb(0, 255, 255);")
        self.TITLE.setAlignment(QtCore.Qt.AlignCenter)
        self.TITLE.setObjectName("TITLE")
        self.verticalLayout.addWidget(self.TITLE)
        self.GROUP_SETTINGS = QtWidgets.QGroupBox(DOORS_REPORT)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.GROUP_SETTINGS.setFont(font)
        self.GROUP_SETTINGS.setObjectName("GROUP_SETTINGS")
        self.gridLayout = QtWidgets.QGridLayout(self.GROUP_SETTINGS)
        self.gridLayout.setObjectName("gridLayout")
        self.EDIT_DIR_WITH_RAW_EXTRACTS = QtWidgets.QLineEdit(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_DIR_WITH_RAW_EXTRACTS.setFont(font)
        self.EDIT_DIR_WITH_RAW_EXTRACTS.setClearButtonEnabled(True)
        self.EDIT_DIR_WITH_RAW_EXTRACTS.setObjectName("EDIT_DIR_WITH_RAW_EXTRACTS")
        self.gridLayout.addWidget(self.EDIT_DIR_WITH_RAW_EXTRACTS, 0, 1, 1, 1)
        self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS = QtWidgets.QPushButton(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS.setFont(font)
        self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS.setObjectName("BTN_BROWSE_DIR_WITH_RAW_EXTRACTS")
        self.gridLayout.addWidget(self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS, 0, 2, 1, 1)
        self.EDIT_SAVE_RESULTS_TO_DIR = QtWidgets.QLineEdit(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_SAVE_RESULTS_TO_DIR.setFont(font)
        self.EDIT_SAVE_RESULTS_TO_DIR.setClearButtonEnabled(True)
        self.EDIT_SAVE_RESULTS_TO_DIR.setObjectName("EDIT_SAVE_RESULTS_TO_DIR")
        self.gridLayout.addWidget(self.EDIT_SAVE_RESULTS_TO_DIR, 1, 1, 1, 1)
        self.LBL_DIR_WITH_RAW_EXTRACTS = QtWidgets.QLabel(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_DIR_WITH_RAW_EXTRACTS.setFont(font)
        self.LBL_DIR_WITH_RAW_EXTRACTS.setObjectName("LBL_DIR_WITH_RAW_EXTRACTS")
        self.gridLayout.addWidget(self.LBL_DIR_WITH_RAW_EXTRACTS, 0, 0, 1, 1)
        self.LBL_SAVE_RESULTS_TO_DIR = QtWidgets.QLabel(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_SAVE_RESULTS_TO_DIR.setFont(font)
        self.LBL_SAVE_RESULTS_TO_DIR.setObjectName("LBL_SAVE_RESULTS_TO_DIR")
        self.gridLayout.addWidget(self.LBL_SAVE_RESULTS_TO_DIR, 1, 0, 1, 1)
        self.BTN_BROWSE_SAVE_RESULTS_TO_DIR = QtWidgets.QPushButton(self.GROUP_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_SAVE_RESULTS_TO_DIR.setFont(font)
        self.BTN_BROWSE_SAVE_RESULTS_TO_DIR.setObjectName("BTN_BROWSE_SAVE_RESULTS_TO_DIR")
        self.gridLayout.addWidget(self.BTN_BROWSE_SAVE_RESULTS_TO_DIR, 1, 2, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 2, 0, 1, 1)
        self.verticalLayout.addWidget(self.GROUP_SETTINGS)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.BTN_SAVE_SETTINGS = QtWidgets.QPushButton(DOORS_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_SAVE_SETTINGS.setFont(font)
        self.BTN_SAVE_SETTINGS.setObjectName("BTN_SAVE_SETTINGS")
        self.horizontalLayout.addWidget(self.BTN_SAVE_SETTINGS)
        self.BTN_CONVERT = QtWidgets.QPushButton(DOORS_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_CONVERT.setFont(font)
        self.BTN_CONVERT.setObjectName("BTN_CONVERT")
        self.horizontalLayout.addWidget(self.BTN_CONVERT)
        self.BTN_OPEN_SAVE_DIR = QtWidgets.QPushButton(DOORS_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_OPEN_SAVE_DIR.setFont(font)
        self.BTN_OPEN_SAVE_DIR.setObjectName("BTN_OPEN_SAVE_DIR")
        self.horizontalLayout.addWidget(self.BTN_OPEN_SAVE_DIR)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.LOG_WIDGET = LogWidget(DOORS_REPORT)
        self.LOG_WIDGET.setObjectName("LOG_WIDGET")
        self.verticalLayout.addWidget(self.LOG_WIDGET)

        self.retranslateUi(DOORS_REPORT)
        QtCore.QMetaObject.connectSlotsByName(DOORS_REPORT)
        DOORS_REPORT.setTabOrder(self.EDIT_DIR_WITH_RAW_EXTRACTS, self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS)
        DOORS_REPORT.setTabOrder(self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS, self.EDIT_SAVE_RESULTS_TO_DIR)
        DOORS_REPORT.setTabOrder(self.EDIT_SAVE_RESULTS_TO_DIR, self.BTN_BROWSE_SAVE_RESULTS_TO_DIR)
        DOORS_REPORT.setTabOrder(self.BTN_BROWSE_SAVE_RESULTS_TO_DIR, self.BTN_SAVE_SETTINGS)
        DOORS_REPORT.setTabOrder(self.BTN_SAVE_SETTINGS, self.BTN_CONVERT)
        DOORS_REPORT.setTabOrder(self.BTN_CONVERT, self.BTN_OPEN_SAVE_DIR)

    def retranslateUi(self, DOORS_REPORT):
        _translate = QtCore.QCoreApplication.translate
        DOORS_REPORT.setWindowTitle(_translate("DOORS_REPORT", "Raw DOORS extracts to nice format converter"))
        self.TITLE.setText(_translate("DOORS_REPORT", "Raw DOORS extracts to nice format converter"))
        self.GROUP_SETTINGS.setTitle(_translate("DOORS_REPORT", "Settings"))
        self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS.setText(_translate("DOORS_REPORT", "browse"))
        self.LBL_DIR_WITH_RAW_EXTRACTS.setText(_translate("DOORS_REPORT", "Dir with raw extracts"))
        self.LBL_SAVE_RESULTS_TO_DIR.setText(_translate("DOORS_REPORT", "Save results to dir"))
        self.BTN_BROWSE_SAVE_RESULTS_TO_DIR.setText(_translate("DOORS_REPORT", "browse"))
        self.BTN_SAVE_SETTINGS.setText(_translate("DOORS_REPORT", "Save settings"))
        self.BTN_CONVERT.setText(_translate("DOORS_REPORT", "Convert"))
        self.BTN_OPEN_SAVE_DIR.setText(_translate("DOORS_REPORT", "Open save dir"))
        #***************************************************************************************************************
        self.BTN_BROWSE_DIR_WITH_RAW_EXTRACTS.pressed.connect(self.browseDirWithRawExtractsPressed)
        self.BTN_BROWSE_SAVE_RESULTS_TO_DIR.pressed.connect(self.browseSaveToPressed)
        self.BTN_SAVE_SETTINGS.pressed.connect(self.saveSettingsPressed)
        self.BTN_CONVERT.pressed.connect(self.convertPressed)
        self.BTN_OPEN_SAVE_DIR.pressed.connect(self.openSaveDirPressed)


    def browseDirWithRawExtractsPressed(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose dir with raw DOORS extracts", options = QtWidgets.QFileDialog.ShowDirsOnly)
        if len(path):
            self.EDIT_DIR_WITH_RAW_EXTRACTS.setText(path)


    def browseSaveToPressed(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose dir where to store results", options = QtWidgets.QFileDialog.ShowDirsOnly)
        if len(path):
            self.EDIT_SAVE_RESULTS_TO_DIR.setText(path)


    def openSaveDirPressed(self):
        path = self.EDIT_SAVE_RESULTS_TO_DIR.text()

        if len(path):
            if FS.isDir(path):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))
            else:
                self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Dir [%s] does not exist" % path, "red"))
        else:
            self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Save dir field is not filled", "red"))


    def saveSettingsPressed(self):
        settings = {
            "dirWithRawDoorsExtracts": self.EDIT_DIR_WITH_RAW_EXTRACTS.text(),
            "saveResultsToDir": self.EDIT_SAVE_RESULTS_TO_DIR.text()
        }

        FS.checkCreateDir("data")
        ND.dict2json(settings, "data/user_settings_doors_report.json")
        self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Currents settings have been saved", "green"))


    def loadSettings(self):
        if FS.isFile("data/user_settings_doors_report.json"):
            settings = ND.json2dict("data/user_settings_doors_report.json")
            self.EDIT_DIR_WITH_RAW_EXTRACTS.setText(settings["dirWithRawDoorsExtracts"])
            self.EDIT_SAVE_RESULTS_TO_DIR.setText(settings["saveResultsToDir"])
            self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Presaved settings have been loaded", "green"))


    def convertPressed(self):
        if self.preStartFieldsCheck():
            self.reportObj.dirWithRawDoorsExtracts = self.EDIT_DIR_WITH_RAW_EXTRACTS.text()
            self.reportObj.saveToDir = self.EDIT_SAVE_RESULTS_TO_DIR.text()
            self.reportObj.endCall = lambda : self.enableControls(True)
            self.enableControls(False)


            Thread(target = self.reportObj.convert).start()


    def preStartFieldsCheck(self):
        result = False

        checkList = list()
        checkList.append(self.checkWidget(self.EDIT_DIR_WITH_RAW_EXTRACTS))
        checkList.append(self.checkWidget(self.EDIT_SAVE_RESULTS_TO_DIR))

        if not False in checkList:
            result = True

        return result


    def checkWidget(self, widget):
        result = False

        if len(widget.text()):
            widget.setStyleSheet("")
            result = True
        else:
            widget.setStyleSheet("background: rgb(255, 0, 0);")
            QtCore.QTimer.singleShot(1000, lambda : widget.setStyleSheet(""))

        return result


    def enableControls(self, boolValue):
        self.GROUP_SETTINGS.setEnabled(boolValue)
        self.BTN_CONVERT.setEnabled(boolValue)