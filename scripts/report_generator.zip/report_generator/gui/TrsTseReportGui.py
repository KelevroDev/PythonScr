from PyQt5 import QtCore, QtGui, QtWidgets
from gui.LogWidget import LogWidget
from utility.FileSystem import FileSystem as FS
from utility.NiceData import NiceData as ND
from utility.htmlCtx import *
from trs_tse_report.TrsTseReport import TrsTseReport
from trs_tse_report.views import *
from threading import Thread
import re



class TrsTseReportGui(QtWidgets.QWidget):
    def __init__(self, parent = None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setupUi(self)
        self.loadSettings()
        self.reportObj = TrsTseReport(self.LOG_WIDGET)
        self.views = [
            "Full data view",
            "Statistics view",
            "Test exec view"
        ]

        self.COMBO_REPORT_VIEW.addItems(self.views)
        self.targetOptionsWidget()

        #***********************************************
        self.BTN_INTERRUPT.setHidden(True)
        self.BTN_CONTINUE.setHidden(True)
        self.CHECK_GET_HBCM_FILES.setHidden(True)
        #***********************************************


    def setupUi(self, TRS_TSE_REPORT):
        TRS_TSE_REPORT.setObjectName("TRS_TSE_REPORT")
        TRS_TSE_REPORT.resize(1200, 700)
        self.gridLayout_2 = QtWidgets.QGridLayout(TRS_TSE_REPORT)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.TITLE = QtWidgets.QLabel(TRS_TSE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.TITLE.sizePolicy().hasHeightForWidth())
        self.TITLE.setSizePolicy(sizePolicy)
        self.TITLE.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setWeight(75)
        self.TITLE.setFont(font)
        self.TITLE.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(162, 162, 162, 255));\n"
"color: rgb(0, 255, 255);")
        self.TITLE.setAlignment(QtCore.Qt.AlignCenter)
        self.TITLE.setObjectName("TITLE")
        self.gridLayout_2.addWidget(self.TITLE, 0, 0, 1, 2)
        self.GROUP_SCRIPT_SETTINGS = QtWidgets.QGroupBox(TRS_TSE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(2)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.GROUP_SCRIPT_SETTINGS.sizePolicy().hasHeightForWidth())
        self.GROUP_SCRIPT_SETTINGS.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.GROUP_SCRIPT_SETTINGS.setFont(font)
        self.GROUP_SCRIPT_SETTINGS.setFlat(False)
        self.GROUP_SCRIPT_SETTINGS.setObjectName("GROUP_SCRIPT_SETTINGS")
        self.gridLayout = QtWidgets.QGridLayout(self.GROUP_SCRIPT_SETTINGS)
        self.gridLayout.setObjectName("gridLayout")
        self.EDIT_PATH_TO_TRS_LIST_FILE = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PATH_TO_TRS_LIST_FILE.setFont(font)
        self.EDIT_PATH_TO_TRS_LIST_FILE.setClearButtonEnabled(True)
        self.EDIT_PATH_TO_TRS_LIST_FILE.setObjectName("EDIT_PATH_TO_TRS_LIST_FILE")
        self.gridLayout.addWidget(self.EDIT_PATH_TO_TRS_LIST_FILE, 0, 1, 1, 1)
        self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE.setFont(font)
        self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE.setObjectName("BTN_BROWSE_PATH_TO_TRS_LIST_FILE")
        self.gridLayout.addWidget(self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE, 0, 2, 1, 1)
        self.LBL_PATH_TO_TRS_LIST = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PATH_TO_TRS_LIST.setFont(font)
        self.LBL_PATH_TO_TRS_LIST.setObjectName("LBL_PATH_TO_TRS_LIST")
        self.gridLayout.addWidget(self.LBL_PATH_TO_TRS_LIST, 0, 0, 1, 1)
        self.LBL_TRS_NAME_FILTER = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_TRS_NAME_FILTER.setFont(font)
        self.LBL_TRS_NAME_FILTER.setObjectName("LBL_TRS_NAME_FILTER")
        self.gridLayout.addWidget(self.LBL_TRS_NAME_FILTER, 1, 0, 1, 1)
        self.LBL_PERFORCE_CLIENT_DIR = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PERFORCE_CLIENT_DIR.setFont(font)
        self.LBL_PERFORCE_CLIENT_DIR.setObjectName("LBL_PERFORCE_CLIENT_DIR")
        self.gridLayout.addWidget(self.LBL_PERFORCE_CLIENT_DIR, 2, 0, 1, 1)
        self.EDIT_PERFORCE_CLIENT_DIR = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PERFORCE_CLIENT_DIR.setFont(font)
        self.EDIT_PERFORCE_CLIENT_DIR.setClearButtonEnabled(True)
        self.EDIT_PERFORCE_CLIENT_DIR.setObjectName("EDIT_PERFORCE_CLIENT_DIR")
        self.gridLayout.addWidget(self.EDIT_PERFORCE_CLIENT_DIR, 2, 1, 1, 1)
        self.COMBO_TRS_NAME_FILTER = QtWidgets.QComboBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.COMBO_TRS_NAME_FILTER.setFont(font)
        self.COMBO_TRS_NAME_FILTER.setEditable(True)
        self.COMBO_TRS_NAME_FILTER.setObjectName("COMBO_TRS_NAME_FILTER")
        self.gridLayout.addWidget(self.COMBO_TRS_NAME_FILTER, 1, 1, 1, 2)
        self.CHECK_EXEC_TESTS_ON_TARGET = QtWidgets.QCheckBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CHECK_EXEC_TESTS_ON_TARGET.setFont(font)
        self.CHECK_EXEC_TESTS_ON_TARGET.setObjectName("CHECK_EXEC_TESTS_ON_TARGET")
        self.gridLayout.addWidget(self.CHECK_EXEC_TESTS_ON_TARGET, 9, 0, 1, 1)
        self.LBL_SAVE_AS = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_SAVE_AS.setFont(font)
        self.LBL_SAVE_AS.setObjectName("LBL_SAVE_AS")
        self.gridLayout.addWidget(self.LBL_SAVE_AS, 5, 0, 1, 1)
        self.CHECK_GET_HBCM_FILES = QtWidgets.QCheckBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CHECK_GET_HBCM_FILES.setFont(font)
        self.CHECK_GET_HBCM_FILES.setObjectName("CHECK_GET_HBCM_FILES")
        self.gridLayout.addWidget(self.CHECK_GET_HBCM_FILES, 7, 0, 1, 1)
        self.LBL_REPORT_VIEW = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_REPORT_VIEW.setFont(font)
        self.LBL_REPORT_VIEW.setObjectName("LBL_REPORT_VIEW")
        self.gridLayout.addWidget(self.LBL_REPORT_VIEW, 4, 0, 1, 1)
        self.CHECK_GET_TEST_BINARIES_FILES = QtWidgets.QCheckBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CHECK_GET_TEST_BINARIES_FILES.setFont(font)
        self.CHECK_GET_TEST_BINARIES_FILES.setObjectName("CHECK_GET_TEST_BINARIES_FILES")
        self.gridLayout.addWidget(self.CHECK_GET_TEST_BINARIES_FILES, 8, 0, 1, 1)
        self.EDIT_SAVE_AS = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_SAVE_AS.setFont(font)
        self.EDIT_SAVE_AS.setClearButtonEnabled(True)
        self.EDIT_SAVE_AS.setObjectName("EDIT_SAVE_AS")
        self.gridLayout.addWidget(self.EDIT_SAVE_AS, 5, 1, 1, 1)
        self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR.setFont(font)
        self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR.setObjectName("BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR")
        self.gridLayout.addWidget(self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR, 3, 2, 1, 1)
        self.BTN_BROWSE_SAVE_AS = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_SAVE_AS.setFont(font)
        self.BTN_BROWSE_SAVE_AS.setObjectName("BTN_BROWSE_SAVE_AS")
        self.gridLayout.addWidget(self.BTN_BROWSE_SAVE_AS, 5, 2, 1, 1)
        self.LBL_PERFORCE_PRODUCTS_DIR = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PERFORCE_PRODUCTS_DIR.setFont(font)
        self.LBL_PERFORCE_PRODUCTS_DIR.setObjectName("LBL_PERFORCE_PRODUCTS_DIR")
        self.gridLayout.addWidget(self.LBL_PERFORCE_PRODUCTS_DIR, 3, 0, 1, 1)
        self.CHECK_GET_HBTS_FILES = QtWidgets.QCheckBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.CHECK_GET_HBTS_FILES.setFont(font)
        self.CHECK_GET_HBTS_FILES.setObjectName("CHECK_GET_HBTS_FILES")
        self.gridLayout.addWidget(self.CHECK_GET_HBTS_FILES, 6, 0, 1, 1)
        self.COMBO_REPORT_VIEW = QtWidgets.QComboBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.COMBO_REPORT_VIEW.setFont(font)
        self.COMBO_REPORT_VIEW.setEditable(False)
        self.COMBO_REPORT_VIEW.setObjectName("COMBO_REPORT_VIEW")
        self.gridLayout.addWidget(self.COMBO_REPORT_VIEW, 4, 1, 1, 2)
        self.EDIT_PERFORCE_PRODUCTS_DIR = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PERFORCE_PRODUCTS_DIR.setFont(font)
        self.EDIT_PERFORCE_PRODUCTS_DIR.setClearButtonEnabled(True)
        self.EDIT_PERFORCE_PRODUCTS_DIR.setObjectName("EDIT_PERFORCE_PRODUCTS_DIR")
        self.gridLayout.addWidget(self.EDIT_PERFORCE_PRODUCTS_DIR, 3, 1, 1, 1)
        self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR.setFont(font)
        self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR.setObjectName("BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR")
        self.gridLayout.addWidget(self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR, 2, 2, 1, 1)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 10, 0, 1, 1)
        self.gridLayout_2.addWidget(self.GROUP_SCRIPT_SETTINGS, 1, 0, 1, 1)
        self.GROUP_TARGET_SETTINGS = QtWidgets.QGroupBox(TRS_TSE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.GROUP_TARGET_SETTINGS.sizePolicy().hasHeightForWidth())
        self.GROUP_TARGET_SETTINGS.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.GROUP_TARGET_SETTINGS.setFont(font)
        self.GROUP_TARGET_SETTINGS.setObjectName("GROUP_TARGET_SETTINGS")
        self.formLayout = QtWidgets.QFormLayout(self.GROUP_TARGET_SETTINGS)
        self.formLayout.setObjectName("formLayout")
        self.LBL_IP = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_IP.setFont(font)
        self.LBL_IP.setObjectName("LBL_IP")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.LBL_IP)
        self.EDIT_IP = QtWidgets.QLineEdit(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_IP.setFont(font)
        self.EDIT_IP.setText("")
        self.EDIT_IP.setClearButtonEnabled(True)
        self.EDIT_IP.setObjectName("EDIT_IP")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.EDIT_IP)
        self.LBL_PORT = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PORT.setFont(font)
        self.LBL_PORT.setObjectName("LBL_PORT")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.LabelRole, self.LBL_PORT)
        self.EDIT_PORT = QtWidgets.QLineEdit(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PORT.setFont(font)
        self.EDIT_PORT.setText("")
        self.EDIT_PORT.setClearButtonEnabled(True)
        self.EDIT_PORT.setObjectName("EDIT_PORT")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.FieldRole, self.EDIT_PORT)
        self.LBL_USER = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_USER.setFont(font)
        self.LBL_USER.setObjectName("LBL_USER")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.LabelRole, self.LBL_USER)
        self.EDIT_USER = QtWidgets.QLineEdit(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_USER.setFont(font)
        self.EDIT_USER.setText("")
        self.EDIT_USER.setClearButtonEnabled(True)
        self.EDIT_USER.setObjectName("EDIT_USER")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.FieldRole, self.EDIT_USER)
        self.LBL_PASSWORD = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PASSWORD.setFont(font)
        self.LBL_PASSWORD.setObjectName("LBL_PASSWORD")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.LabelRole, self.LBL_PASSWORD)
        self.EDIT_PASSWORD = QtWidgets.QLineEdit(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PASSWORD.setFont(font)
        self.EDIT_PASSWORD.setText("")
        self.EDIT_PASSWORD.setClearButtonEnabled(True)
        self.EDIT_PASSWORD.setObjectName("EDIT_PASSWORD")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.FieldRole, self.EDIT_PASSWORD)
        self.LBL_DIR_FOR_TEST_BINARIES = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_DIR_FOR_TEST_BINARIES.setFont(font)
        self.LBL_DIR_FOR_TEST_BINARIES.setObjectName("LBL_DIR_FOR_TEST_BINARIES")
        self.formLayout.setWidget(4, QtWidgets.QFormLayout.LabelRole, self.LBL_DIR_FOR_TEST_BINARIES)
        self.EDIT_DIR_FOR_TEST_BINARIES = QtWidgets.QLineEdit(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_DIR_FOR_TEST_BINARIES.setFont(font)
        self.EDIT_DIR_FOR_TEST_BINARIES.setText("")
        self.EDIT_DIR_FOR_TEST_BINARIES.setClearButtonEnabled(True)
        self.EDIT_DIR_FOR_TEST_BINARIES.setObjectName("EDIT_DIR_FOR_TEST_BINARIES")
        self.formLayout.setWidget(4, QtWidgets.QFormLayout.FieldRole, self.EDIT_DIR_FOR_TEST_BINARIES)
        self.LBL_EXEC_PRE_CONFIG = QtWidgets.QLabel(self.GROUP_TARGET_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_EXEC_PRE_CONFIG.setFont(font)
        self.LBL_EXEC_PRE_CONFIG.setObjectName("LBL_EXEC_PRE_CONFIG")
        self.formLayout.setWidget(5, QtWidgets.QFormLayout.LabelRole, self.LBL_EXEC_PRE_CONFIG)
        self.EDIT_EXEC_PRE_CONFIG = QtWidgets.QPlainTextEdit(self.GROUP_TARGET_SETTINGS)
        self.EDIT_EXEC_PRE_CONFIG.setMinimumSize(QtCore.QSize(0, 10))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_EXEC_PRE_CONFIG.setFont(font)
        self.EDIT_EXEC_PRE_CONFIG.setObjectName("EDIT_EXEC_PRE_CONFIG")
        self.formLayout.setWidget(5, QtWidgets.QFormLayout.FieldRole, self.EDIT_EXEC_PRE_CONFIG)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.formLayout.setItem(6, QtWidgets.QFormLayout.LabelRole, spacerItem1)
        spacerItem2 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.formLayout.setItem(6, QtWidgets.QFormLayout.FieldRole, spacerItem2)
        self.gridLayout_2.addWidget(self.GROUP_TARGET_SETTINGS, 1, 1, 1, 1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.BTN_SAVE_SETTINGS = QtWidgets.QPushButton(TRS_TSE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_SAVE_SETTINGS.setFont(font)
        self.BTN_SAVE_SETTINGS.setObjectName("BTN_SAVE_SETTINGS")
        self.horizontalLayout.addWidget(self.BTN_SAVE_SETTINGS)
        self.BTN_CONTINUE = QtWidgets.QPushButton(TRS_TSE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_CONTINUE.setFont(font)
        self.BTN_CONTINUE.setObjectName("BTN_CONTINUE")
        self.horizontalLayout.addWidget(self.BTN_CONTINUE)
        self.BTN_START = QtWidgets.QPushButton(TRS_TSE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_START.setFont(font)
        self.BTN_START.setObjectName("BTN_START")
        self.horizontalLayout.addWidget(self.BTN_START)
        self.BTN_INTERRUPT = QtWidgets.QPushButton(TRS_TSE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_INTERRUPT.setFont(font)
        self.BTN_INTERRUPT.setObjectName("BTN_INTERRUPT")
        self.horizontalLayout.addWidget(self.BTN_INTERRUPT)
        self.BTN_OPEN_SAVE_FOLDER = QtWidgets.QPushButton(TRS_TSE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_OPEN_SAVE_FOLDER.setFont(font)
        self.BTN_OPEN_SAVE_FOLDER.setObjectName("BTN_OPEN_SAVE_FOLDER")
        self.horizontalLayout.addWidget(self.BTN_OPEN_SAVE_FOLDER)
        self.gridLayout_2.addLayout(self.horizontalLayout, 2, 0, 1, 2)
        self.LOG_WIDGET = LogWidget(TRS_TSE_REPORT)
        self.LOG_WIDGET.setObjectName("LOG_WIDGET")
        self.gridLayout_2.addWidget(self.LOG_WIDGET, 3, 0, 1, 2)

        self.retranslateUi(TRS_TSE_REPORT)
        QtCore.QMetaObject.connectSlotsByName(TRS_TSE_REPORT)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_PATH_TO_TRS_LIST_FILE, self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE)
        TRS_TSE_REPORT.setTabOrder(self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE, self.COMBO_TRS_NAME_FILTER)
        TRS_TSE_REPORT.setTabOrder(self.COMBO_TRS_NAME_FILTER, self.EDIT_PERFORCE_CLIENT_DIR)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_PERFORCE_CLIENT_DIR, self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR)
        TRS_TSE_REPORT.setTabOrder(self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR, self.EDIT_PERFORCE_PRODUCTS_DIR)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_PERFORCE_PRODUCTS_DIR, self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR)
        TRS_TSE_REPORT.setTabOrder(self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR, self.COMBO_REPORT_VIEW)
        TRS_TSE_REPORT.setTabOrder(self.COMBO_REPORT_VIEW, self.EDIT_SAVE_AS)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_SAVE_AS, self.BTN_BROWSE_SAVE_AS)
        TRS_TSE_REPORT.setTabOrder(self.BTN_BROWSE_SAVE_AS, self.CHECK_GET_HBTS_FILES)
        TRS_TSE_REPORT.setTabOrder(self.CHECK_GET_HBTS_FILES, self.CHECK_GET_HBCM_FILES)
        TRS_TSE_REPORT.setTabOrder(self.CHECK_GET_HBCM_FILES, self.CHECK_GET_TEST_BINARIES_FILES)
        TRS_TSE_REPORT.setTabOrder(self.CHECK_GET_TEST_BINARIES_FILES, self.CHECK_EXEC_TESTS_ON_TARGET)
        TRS_TSE_REPORT.setTabOrder(self.CHECK_EXEC_TESTS_ON_TARGET, self.EDIT_IP)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_IP, self.EDIT_PORT)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_PORT, self.EDIT_USER)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_USER, self.EDIT_PASSWORD)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_PASSWORD, self.EDIT_DIR_FOR_TEST_BINARIES)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_DIR_FOR_TEST_BINARIES, self.EDIT_EXEC_PRE_CONFIG)
        TRS_TSE_REPORT.setTabOrder(self.EDIT_EXEC_PRE_CONFIG, self.BTN_SAVE_SETTINGS)
        TRS_TSE_REPORT.setTabOrder(self.BTN_SAVE_SETTINGS, self.BTN_CONTINUE)
        TRS_TSE_REPORT.setTabOrder(self.BTN_CONTINUE, self.BTN_START)
        TRS_TSE_REPORT.setTabOrder(self.BTN_START, self.BTN_INTERRUPT)

    def retranslateUi(self, TRS_TSE_REPORT):
        _translate = QtCore.QCoreApplication.translate
        TRS_TSE_REPORT.setWindowTitle(_translate("TRS_TSE_REPORT", "TRS TSE report"))
        self.TITLE.setText(_translate("TRS_TSE_REPORT", "TRS TSE report"))
        self.GROUP_SCRIPT_SETTINGS.setTitle(_translate("TRS_TSE_REPORT", "Script settings"))
        self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE.setText(_translate("TRS_TSE_REPORT", "browse"))
        self.LBL_PATH_TO_TRS_LIST.setText(_translate("TRS_TSE_REPORT", "Path to trs list file"))
        self.LBL_TRS_NAME_FILTER.setText(_translate("TRS_TSE_REPORT", "Trs name filter"))
        self.LBL_PERFORCE_CLIENT_DIR.setText(_translate("TRS_TSE_REPORT", "Perforce client dir"))
        self.CHECK_EXEC_TESTS_ON_TARGET.setText(_translate("TRS_TSE_REPORT", "Exec tests on target"))
        self.LBL_SAVE_AS.setText(_translate("TRS_TSE_REPORT", "Save report as"))
        self.CHECK_GET_HBCM_FILES.setText(_translate("TRS_TSE_REPORT", "Get hbcm files"))
        self.LBL_REPORT_VIEW.setText(_translate("TRS_TSE_REPORT", "Report view"))
        self.CHECK_GET_TEST_BINARIES_FILES.setText(_translate("TRS_TSE_REPORT", "Get test binaries files"))
        self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR.setText(_translate("TRS_TSE_REPORT", "browse"))
        self.BTN_BROWSE_SAVE_AS.setText(_translate("TRS_TSE_REPORT", "browse"))
        self.LBL_PERFORCE_PRODUCTS_DIR.setText(_translate("TRS_TSE_REPORT", "Perforce products dir"))
        self.CHECK_GET_HBTS_FILES.setText(_translate("TRS_TSE_REPORT", "Get hbts files"))
        self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR.setText(_translate("TRS_TSE_REPORT", "browse"))
        self.GROUP_TARGET_SETTINGS.setTitle(_translate("TRS_TSE_REPORT", "Target settings"))
        self.LBL_IP.setText(_translate("TRS_TSE_REPORT", "IP"))
        self.LBL_PORT.setText(_translate("TRS_TSE_REPORT", "Port"))
        self.LBL_USER.setText(_translate("TRS_TSE_REPORT", "User"))
        self.LBL_PASSWORD.setText(_translate("TRS_TSE_REPORT", "Password"))
        self.LBL_DIR_FOR_TEST_BINARIES.setText(_translate("TRS_TSE_REPORT", "Dir for test binaries"))
        self.LBL_EXEC_PRE_CONFIG.setText(_translate("TRS_TSE_REPORT", "Exec pre config"))
        self.BTN_SAVE_SETTINGS.setText(_translate("TRS_TSE_REPORT", "Save settings"))
        self.BTN_CONTINUE.setText(_translate("TRS_TSE_REPORT", "Continue"))
        self.BTN_START.setText(_translate("TRS_TSE_REPORT", "Start"))
        self.BTN_INTERRUPT.setText(_translate("TRS_TSE_REPORT", "Interrupt"))
        self.BTN_OPEN_SAVE_FOLDER.setText(_translate("TRS_TSE_REPORT", "Open save folder"))
        #***************************************************************************************************************
        self.BTN_BROWSE_PATH_TO_TRS_LIST_FILE.pressed.connect(self.browsePathToTrsListFilePressed)
        self.BTN_BROWSE_PATH_TO_PERFORCE_CLIENT_DIR.pressed.connect(self.browsePerforceClientDirPressed)
        self.BTN_BROWSE_PATH_TO_PERFORCE_PRODUCTS_DIR.pressed.connect(self.browsePerforceProductsDirPressed)
        self.BTN_BROWSE_SAVE_AS.pressed.connect(self.browseSaveReportAs)
        self.BTN_CONTINUE.pressed.connect(self.continuePressed)
        self.BTN_START.pressed.connect(self.startPressed)
        self.BTN_INTERRUPT.pressed.connect(self.interruptPressed)
        self.BTN_SAVE_SETTINGS.pressed.connect(self.saveSettingsPressed)
        self.BTN_OPEN_SAVE_FOLDER.pressed.connect(self.openSaveDirPressed)
        self.CHECK_EXEC_TESTS_ON_TARGET.stateChanged.connect(self.targetOptionsWidget)


    def targetOptionsWidget(self):
        if self.CHECK_EXEC_TESTS_ON_TARGET.isChecked():
            self.GROUP_TARGET_SETTINGS.setHidden(False)
        else:
            self.GROUP_TARGET_SETTINGS.setHidden(True)


    def browsePathToTrsListFilePressed(self):
        path = QtWidgets.QFileDialog.getOpenFileName(self, "Choose trs list file", "","*.txt", ".*")[0]
        if len(path):
            self.EDIT_PATH_TO_TRS_LIST_FILE.setText(path)
            self.fillTrsNameFilterCombo()


    def browsePerforceClientDirPressed(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose you perforce client dir", options = QtWidgets.QFileDialog.ShowDirsOnly)
        if len(path):
            self.EDIT_PERFORCE_CLIENT_DIR.setText(path)


    def browsePerforceProductsDirPressed(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Choose you perforce products dir", options = QtWidgets.QFileDialog.ShowDirsOnly)
        if len(path):
            self.EDIT_PERFORCE_PRODUCTS_DIR.setText(path)


    def browseSaveReportAs(self):
        x = QtWidgets.QFileDialog.getSaveFileName(self,
                                                     "Save report as",
                                                     "trs_tse_coverage_report",
                                                     ".xlsx")
                                                     #"MS Excel file .xlsx;;HTML file .html")[0]
        if len(x[0]):
            path = x[0]

            if not x[1] in path:
                path += x[1]

            self.EDIT_SAVE_AS.setText(path)


    def openSaveDirPressed(self):
        if len(self.EDIT_SAVE_AS.text()):
            path = FS.dirName(self.EDIT_SAVE_AS.text())

            if FS.isDir(path):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))


    def saveSettingsPressed(self):
        settings = {
            "pathToTrsListFile": self.EDIT_PATH_TO_TRS_LIST_FILE.text(),
            "trsNameFilter": self.COMBO_TRS_NAME_FILTER.currentText(),
            "perforceClientDir": self.EDIT_PERFORCE_CLIENT_DIR.text(),
            "perforceProductsDir": self.EDIT_PERFORCE_PRODUCTS_DIR.text(),
            "reportView": self.COMBO_REPORT_VIEW.currentText(),
            "saveReportAs": self.EDIT_SAVE_AS.text(),
            "getHbtsFiles": self.CHECK_GET_HBTS_FILES.isChecked(),
            "getHbcmFiles": self.CHECK_GET_HBCM_FILES.isChecked(),
            "getBinFiles": self.CHECK_GET_TEST_BINARIES_FILES.isChecked(),
            "execTests": self.CHECK_EXEC_TESTS_ON_TARGET.isChecked(),
            "ip": self.EDIT_IP.text(),
            "port": self.EDIT_PORT.text(),
            "user": self.EDIT_USER.text(),
            "password": self.EDIT_PASSWORD.text(),
            "binDir": self.EDIT_DIR_FOR_TEST_BINARIES.text(),
            "execPreConfig": self.EDIT_EXEC_PRE_CONFIG.toPlainText().strip()
        }

        FS.checkCreateDir("data")
        ND.dict2json(settings, "data/user_settings_trs_tse_report.json")

        self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Currents settings have been saved", "green"))


    def loadSettings(self):
        if FS.isFile("data/user_settings_trs_tse_report.json"):
            settings = ND.json2dict("data/user_settings_trs_tse_report.json")

            self.EDIT_PATH_TO_TRS_LIST_FILE.setText(settings["pathToTrsListFile"])
            self.fillTrsNameFilterCombo()
            self.COMBO_TRS_NAME_FILTER.setCurrentText(settings["trsNameFilter"])
            self.EDIT_PERFORCE_CLIENT_DIR.setText(settings["perforceClientDir"])
            self.EDIT_PERFORCE_PRODUCTS_DIR.setText(settings["perforceProductsDir"])
            self.COMBO_REPORT_VIEW.setCurrentText(settings["reportView"])
            self.EDIT_SAVE_AS.setText(settings["saveReportAs"])
            self.CHECK_GET_HBTS_FILES.setChecked(settings["getHbtsFiles"])
            self.CHECK_GET_HBCM_FILES.setChecked(settings["getHbcmFiles"])
            self.CHECK_GET_TEST_BINARIES_FILES.setChecked(settings["getBinFiles"])
            self.CHECK_EXEC_TESTS_ON_TARGET.setChecked(settings["execTests"])
            self.EDIT_IP.setText(settings["ip"])
            self.EDIT_PORT.setText(settings["port"])
            self.EDIT_USER.setText(settings["user"])
            self.EDIT_PASSWORD.setText(settings["password"])
            self.EDIT_DIR_FOR_TEST_BINARIES.setText(settings["binDir"])
            self.EDIT_EXEC_PRE_CONFIG.setPlainText(settings["execPreConfig"])

            self.targetOptionsWidget()
            self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Presaved settings have been loaded", "green"))


    def startPressed(self):
        if self.preStartFieldsCheck():
            self.reportObj.trsListPath = self.EDIT_PATH_TO_TRS_LIST_FILE.text()
            self.reportObj.trsFilter = self.COMBO_TRS_NAME_FILTER.currentText()
            self.reportObj.clientDir = self.EDIT_PERFORCE_CLIENT_DIR.text()
            self.reportObj.productsDir = self.EDIT_PERFORCE_PRODUCTS_DIR.text()
            self.reportObj.targetIp = self.EDIT_IP.text()
            self.reportObj.targetPort = self.EDIT_PORT.text()
            self.reportObj.targetUser = self.EDIT_USER.text()
            self.reportObj.targetPassword = self.EDIT_PASSWORD.text()
            self.reportObj.targetBinDir = self.EDIT_DIR_FOR_TEST_BINARIES.text()
            self.reportObj.preExecSettings = self.compilePreExecSettings()
            self.reportObj.getHbtsOption = self.CHECK_GET_HBTS_FILES.isChecked()
            self.reportObj.getHbcmOption = self.CHECK_GET_HBCM_FILES.isChecked()
            self.reportObj.getBinOption = self.CHECK_GET_TEST_BINARIES_FILES.isChecked()
            self.reportObj.execTestsOption = self.CHECK_EXEC_TESTS_ON_TARGET.isChecked()
            self.reportObj.endCall = self.createReport

            self.enableControls(False)

            Thread(target=self.reportObj.start).start()


    def continuePressed(self):
        pass


    def interruptPressed(self):
        self.reportObj.INTERRUPT_PROCESS_FLAG = True


    def createReport(self):
        path = self.EDIT_SAVE_AS.text()

        if self.COMBO_REPORT_VIEW.currentText()  == "Full data view":
            allDataView(self.reportObj.features, path)

        elif self.COMBO_REPORT_VIEW.currentText()  == "Statistics view":
            statisticsView(self.reportObj.features, path)

        elif self.COMBO_REPORT_VIEW.currentText() == "Test exec view":
            testExecView(self.reportObj.features, path)

        self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr('Report has been saved as %s' % self.EDIT_SAVE_AS.text(), "green"))

        self.enableControls(True)


    def fillTrsNameFilterCombo(self):
        self.COMBO_TRS_NAME_FILTER.clear()
        possibleFilters = [""]
        path = self.EDIT_PATH_TO_TRS_LIST_FILE.text().strip()

        if FS.isFile(path):
            with open(path) as file:
                possibleFilters += re.findall("TRS-MEUCY17-([\w]+)-", file.read())
                possibleFilters = sorted(list(set(possibleFilters)))

        self.COMBO_TRS_NAME_FILTER.addItems(possibleFilters)


    def preStartFieldsCheck(self):
        result = False

        checkList = list()

        checkList.append(self.checkWidget(self.EDIT_PATH_TO_TRS_LIST_FILE))
        checkList.append(self.checkWidget(self.EDIT_SAVE_AS))


        if self.CHECK_GET_HBTS_FILES.isChecked():
            checkList.append(self.checkWidget(self.EDIT_PERFORCE_CLIENT_DIR))

        if self.CHECK_GET_TEST_BINARIES_FILES.isChecked():
            checkList.append(self.checkWidget(self.EDIT_PERFORCE_PRODUCTS_DIR))

        if self.CHECK_EXEC_TESTS_ON_TARGET.isChecked():
            checkList.append(self.checkWidget(self.EDIT_IP))
            checkList.append(self.checkWidget(self.EDIT_PORT))
            checkList.append(self.checkWidget(self.EDIT_USER))
            checkList.append(self.checkWidget(self.EDIT_PASSWORD))
            checkList.append(self.checkWidget(self.EDIT_DIR_FOR_TEST_BINARIES))

        if not False in checkList:
            result = True

        return result


    def checkWidget(self, widget):
        result = False

        if len(widget.text()):
            widget.setStyleSheet("")
            result = True
        else:
            widget.setStyleSheet("background: rgb(255, 0, 0);")
            QtCore.QTimer.singleShot(1000, lambda : widget.setStyleSheet(""))

        return result


    def compilePreExecSettings(self):
        result = str()
        k = self.EDIT_EXEC_PRE_CONFIG.toPlainText().strip()

        if len(k):
            pre = k.split("\n")
            result = " && ".join(pre) + " && "

        return result


    def enableControls(self, boolValue):
        self.GROUP_TARGET_SETTINGS.setEnabled(boolValue)
        self.GROUP_SCRIPT_SETTINGS.setEnabled(boolValue)
        self.BTN_START.setEnabled(boolValue)