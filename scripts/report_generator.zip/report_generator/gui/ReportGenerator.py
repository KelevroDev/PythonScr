from PyQt5 import QtCore, QtGui, QtWidgets
from gui.TrsTseReportGui import TrsTseReportGui
from gui.DoorsReportGui import DoorsReportGui
from gui.CrucibleReportGui import CrucibleReportGui



class ReportGenerator(QtWidgets.QWidget):
    def __init__(self, parent = None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setupUi(self)


    def setupUi(self, REPORT_GENERATOR):
        REPORT_GENERATOR.setObjectName("REPORT_GENERATOR")
        REPORT_GENERATOR.resize(1200, 800)
        self.verticalLayout = QtWidgets.QVBoxLayout(REPORT_GENERATOR)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.LBL_TITLE = QtWidgets.QLabel(REPORT_GENERATOR)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.LBL_TITLE.sizePolicy().hasHeightForWidth())
        self.LBL_TITLE.setSizePolicy(sizePolicy)
        self.LBL_TITLE.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setWeight(75)
        self.LBL_TITLE.setFont(font)
        self.LBL_TITLE.setStyleSheet("background-color: qlineargradient(spread:pad, x1:1, y1:0, x2:0, y2:0, stop:0 rgba(0, 57, 72, 255), stop:1 rgba(62, 198, 255, 255));\n"
"color: rgb(0, 255, 255);")
        self.LBL_TITLE.setAlignment(QtCore.Qt.AlignCenter)
        self.LBL_TITLE.setObjectName("LBL_TITLE")
        self.verticalLayout.addWidget(self.LBL_TITLE)
        self.TAB_WIDGET = QtWidgets.QTabWidget(REPORT_GENERATOR)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.TAB_WIDGET.setFont(font)
        self.TAB_WIDGET.setObjectName("TAB_WIDGET")
        self.TAB_DOORS = DoorsReportGui()
        self.TAB_DOORS.setObjectName("TAB_DOORS")
        self.TAB_WIDGET.addTab(self.TAB_DOORS, "")
        self.TAB_TSE = TrsTseReportGui()
        self.TAB_TSE.setObjectName("TAB_TSE")
        self.TAB_WIDGET.addTab(self.TAB_TSE, "")
        self.TAB_CRUCIBLE = CrucibleReportGui()
        self.TAB_CRUCIBLE.setObjectName("TAB_CRUCIBLE")
        self.TAB_WIDGET.addTab(self.TAB_CRUCIBLE, "")
        self.TAB_LINT = QtWidgets.QWidget()
        self.TAB_LINT.setObjectName("TAB_LINT")
        self.TAB_WIDGET.addTab(self.TAB_LINT, "")
        self.TAB_LOC = QtWidgets.QWidget()
        self.TAB_LOC.setObjectName("TAB_LOC")
        self.TAB_WIDGET.addTab(self.TAB_LOC, "")
        self.verticalLayout.addWidget(self.TAB_WIDGET)

        self.retranslateUi(REPORT_GENERATOR)
        self.TAB_WIDGET.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(REPORT_GENERATOR)

    def retranslateUi(self, REPORT_GENERATOR):
        _translate = QtCore.QCoreApplication.translate
        REPORT_GENERATOR.setWindowTitle(_translate("REPORT_GENERATOR", "Report genarator"))
        self.LBL_TITLE.setText(_translate("REPORT_GENERATOR", "Report generator"))
        self.TAB_WIDGET.setTabText(self.TAB_WIDGET.indexOf(self.TAB_DOORS), _translate("REPORT_GENERATOR", "DOORS"))
        self.TAB_WIDGET.setTabText(self.TAB_WIDGET.indexOf(self.TAB_TSE), _translate("REPORT_GENERATOR", "TSE"))
        self.TAB_WIDGET.setTabText(self.TAB_WIDGET.indexOf(self.TAB_CRUCIBLE), _translate("REPORT_GENERATOR", "CRUCIBLE"))
        self.TAB_WIDGET.setTabText(self.TAB_WIDGET.indexOf(self.TAB_LINT), _translate("REPORT_GENERATOR", "LINT"))
        self.TAB_WIDGET.setTabText(self.TAB_WIDGET.indexOf(self.TAB_LOC), _translate("REPORT_GENERATOR", "LOC"))

