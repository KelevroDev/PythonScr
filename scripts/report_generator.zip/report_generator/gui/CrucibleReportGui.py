from PyQt5 import QtCore, QtGui, QtWidgets
from gui.LogWidget import LogWidget
from utility.FileSystem import FileSystem as FS
from utility.NiceData import NiceData as ND
from utility.htmlCtx import *
from crusible_report.CrucibleReport import CrucibleReport
from threading import Thread
import re


class CrucibleReportGui(QtWidgets.QWidget):
    def __init__(self, parent = None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setupUi(self)

        now = QtCore.QDate.currentDate()
        self.DATE_FROM.setDate(now.addDays(-7))
        self.DATE_TO.setDate(now)

        self.loadSettings()
        self.reportObj = CrucibleReport(self.LOG_WIDGET)


    def setupUi(self, CRUCIBLE_REPORT):
        CRUCIBLE_REPORT.setObjectName("CRUCIBLE_REPORT")
        CRUCIBLE_REPORT.resize(1200, 800)
        self.gridLayout_2 = QtWidgets.QGridLayout(CRUCIBLE_REPORT)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.TITLE = QtWidgets.QLabel(CRUCIBLE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.TITLE.sizePolicy().hasHeightForWidth())
        self.TITLE.setSizePolicy(sizePolicy)
        self.TITLE.setMinimumSize(QtCore.QSize(0, 30))
        font = QtGui.QFont()
        font.setPointSize(13)
        font.setBold(True)
        font.setWeight(75)
        self.TITLE.setFont(font)
        self.TITLE.setStyleSheet("background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(162, 162, 162, 255));\n"
"color: rgb(0, 255, 255);")
        self.TITLE.setAlignment(QtCore.Qt.AlignCenter)
        self.TITLE.setObjectName("TITLE")
        self.gridLayout_2.addWidget(self.TITLE, 0, 0, 1, 2)
        self.GROUP_SCRIPT_SETTINGS = QtWidgets.QGroupBox(CRUCIBLE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(2)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.GROUP_SCRIPT_SETTINGS.sizePolicy().hasHeightForWidth())
        self.GROUP_SCRIPT_SETTINGS.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.GROUP_SCRIPT_SETTINGS.setFont(font)
        self.GROUP_SCRIPT_SETTINGS.setObjectName("GROUP_SCRIPT_SETTINGS")
        self.gridLayout = QtWidgets.QGridLayout(self.GROUP_SCRIPT_SETTINGS)
        self.gridLayout.setObjectName("gridLayout")
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 8, 0, 1, 1)
        self.COMBO_REPORT_VIEW = QtWidgets.QComboBox(self.GROUP_SCRIPT_SETTINGS)
        self.COMBO_REPORT_VIEW.setObjectName("COMBO_REPORT_VIEW")
        self.gridLayout.addWidget(self.COMBO_REPORT_VIEW, 7, 1, 1, 2)
        self.BTN_BROWSE_EMPLOYEE_MAPPING = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_EMPLOYEE_MAPPING.setFont(font)
        self.BTN_BROWSE_EMPLOYEE_MAPPING.setObjectName("BTN_BROWSE_EMPLOYEE_MAPPING")
        self.gridLayout.addWidget(self.BTN_BROWSE_EMPLOYEE_MAPPING, 6, 2, 1, 1)
        self.EDIT_EMPLOYEE_MAPPING = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_EMPLOYEE_MAPPING.setFont(font)
        self.EDIT_EMPLOYEE_MAPPING.setClearButtonEnabled(True)
        self.EDIT_EMPLOYEE_MAPPING.setObjectName("EDIT_EMPLOYEE_MAPPING")
        self.gridLayout.addWidget(self.EDIT_EMPLOYEE_MAPPING, 6, 1, 1, 1)
        self.LBL_EMPLOYEE_MAPPING = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_EMPLOYEE_MAPPING.setFont(font)
        self.LBL_EMPLOYEE_MAPPING.setObjectName("LBL_EMPLOYEE_MAPPING")
        self.gridLayout.addWidget(self.LBL_EMPLOYEE_MAPPING, 6, 0, 1, 1)
        self.BTN_BROWSE_DOMAIN_MAPPING = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_DOMAIN_MAPPING.setFont(font)
        self.BTN_BROWSE_DOMAIN_MAPPING.setObjectName("BTN_BROWSE_DOMAIN_MAPPING")
        self.gridLayout.addWidget(self.BTN_BROWSE_DOMAIN_MAPPING, 5, 2, 1, 1)
        self.EDIT_DOMAIN_MAPPING = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_DOMAIN_MAPPING.setFont(font)
        self.EDIT_DOMAIN_MAPPING.setClearButtonEnabled(True)
        self.EDIT_DOMAIN_MAPPING.setObjectName("EDIT_DOMAIN_MAPPING")
        self.gridLayout.addWidget(self.EDIT_DOMAIN_MAPPING, 5, 1, 1, 1)
        self.LBL_DOMAIN_MAPPING = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_DOMAIN_MAPPING.setFont(font)
        self.LBL_DOMAIN_MAPPING.setObjectName("LBL_DOMAIN_MAPPING")
        self.gridLayout.addWidget(self.LBL_DOMAIN_MAPPING, 5, 0, 1, 1)
        self.SPIN_THREAD_COUNT = QtWidgets.QSpinBox(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.SPIN_THREAD_COUNT.setFont(font)
        self.SPIN_THREAD_COUNT.setMinimum(1)
        self.SPIN_THREAD_COUNT.setMaximum(12)
        self.SPIN_THREAD_COUNT.setObjectName("SPIN_THREAD_COUNT")
        self.gridLayout.addWidget(self.SPIN_THREAD_COUNT, 4, 1, 1, 2)
        self.LBL_THREAD_COUNT = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_THREAD_COUNT.setFont(font)
        self.LBL_THREAD_COUNT.setObjectName("LBL_THREAD_COUNT")
        self.gridLayout.addWidget(self.LBL_THREAD_COUNT, 4, 0, 1, 1)
        self.BTN_BROWSE_SAVE_REPORT_AS = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_SAVE_REPORT_AS.setFont(font)
        self.BTN_BROWSE_SAVE_REPORT_AS.setObjectName("BTN_BROWSE_SAVE_REPORT_AS")
        self.gridLayout.addWidget(self.BTN_BROWSE_SAVE_REPORT_AS, 3, 2, 1, 1)
        self.EDIT_SAVE_REPORTS_AS = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_SAVE_REPORTS_AS.setFont(font)
        self.EDIT_SAVE_REPORTS_AS.setClearButtonEnabled(True)
        self.EDIT_SAVE_REPORTS_AS.setObjectName("EDIT_SAVE_REPORTS_AS")
        self.gridLayout.addWidget(self.EDIT_SAVE_REPORTS_AS, 3, 1, 1, 1)
        self.LBL_SAVE_REPORT_AS = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_SAVE_REPORT_AS.setFont(font)
        self.LBL_SAVE_REPORT_AS.setObjectName("LBL_SAVE_REPORT_AS")
        self.gridLayout.addWidget(self.LBL_SAVE_REPORT_AS, 3, 0, 1, 1)
        self.DATE_TO = QtWidgets.QDateEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.DATE_TO.setFont(font)
        self.DATE_TO.setCalendarPopup(True)
        self.DATE_TO.setObjectName("DATE_TO")
        self.gridLayout.addWidget(self.DATE_TO, 2, 1, 1, 2)
        self.LBL_DATE_TO = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_DATE_TO.setFont(font)
        self.LBL_DATE_TO.setObjectName("LBL_DATE_TO")
        self.gridLayout.addWidget(self.LBL_DATE_TO, 2, 0, 1, 1)
        self.DATE_FROM = QtWidgets.QDateEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.DATE_FROM.setFont(font)
        self.DATE_FROM.setCalendarPopup(True)
        self.DATE_FROM.setObjectName("DATE_FROM")
        self.gridLayout.addWidget(self.DATE_FROM, 1, 1, 1, 2)
        self.LBL_DATE_FROM = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_DATE_FROM.setFont(font)
        self.LBL_DATE_FROM.setObjectName("LBL_DATE_FROM")
        self.gridLayout.addWidget(self.LBL_DATE_FROM, 1, 0, 1, 1)
        self.LBL_P4_CHANGES_FILE = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_P4_CHANGES_FILE.setFont(font)
        self.LBL_P4_CHANGES_FILE.setObjectName("LBL_P4_CHANGES_FILE")
        self.gridLayout.addWidget(self.LBL_P4_CHANGES_FILE, 0, 0, 1, 1)
        self.BTN_BROWSE_P4_CHANGES_FILE = QtWidgets.QPushButton(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.BTN_BROWSE_P4_CHANGES_FILE.setFont(font)
        self.BTN_BROWSE_P4_CHANGES_FILE.setObjectName("BTN_BROWSE_P4_CHANGES_FILE")
        self.gridLayout.addWidget(self.BTN_BROWSE_P4_CHANGES_FILE, 0, 2, 1, 1)
        self.EDIT_P4_CHANGES_FILE = QtWidgets.QLineEdit(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_P4_CHANGES_FILE.setFont(font)
        self.EDIT_P4_CHANGES_FILE.setClearButtonEnabled(True)
        self.EDIT_P4_CHANGES_FILE.setObjectName("EDIT_P4_CHANGES_FILE")
        self.gridLayout.addWidget(self.EDIT_P4_CHANGES_FILE, 0, 1, 1, 1)
        self.LBL_REPORT_VIEW = QtWidgets.QLabel(self.GROUP_SCRIPT_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_REPORT_VIEW.setFont(font)
        self.LBL_REPORT_VIEW.setObjectName("LBL_REPORT_VIEW")
        self.gridLayout.addWidget(self.LBL_REPORT_VIEW, 7, 0, 1, 1)
        self.gridLayout_2.addWidget(self.GROUP_SCRIPT_SETTINGS, 1, 0, 1, 1)
        self.GROUP_CRUCIBLE_SETTINGS = QtWidgets.QGroupBox(CRUCIBLE_REPORT)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.GROUP_CRUCIBLE_SETTINGS.sizePolicy().hasHeightForWidth())
        self.GROUP_CRUCIBLE_SETTINGS.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.GROUP_CRUCIBLE_SETTINGS.setFont(font)
        self.GROUP_CRUCIBLE_SETTINGS.setObjectName("GROUP_CRUCIBLE_SETTINGS")
        self.formLayout = QtWidgets.QFormLayout(self.GROUP_CRUCIBLE_SETTINGS)
        self.formLayout.setObjectName("formLayout")
        self.LBL_PASSWORD = QtWidgets.QLabel(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_PASSWORD.setFont(font)
        self.LBL_PASSWORD.setObjectName("LBL_PASSWORD")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.LabelRole, self.LBL_PASSWORD)
        self.LBL_USER = QtWidgets.QLabel(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_USER.setFont(font)
        self.LBL_USER.setObjectName("LBL_USER")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.LabelRole, self.LBL_USER)
        self.LBL_URL = QtWidgets.QLabel(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.LBL_URL.setFont(font)
        self.LBL_URL.setObjectName("LBL_URL")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.LabelRole, self.LBL_URL)
        self.EDIT_URL = QtWidgets.QLineEdit(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_URL.setFont(font)
        self.EDIT_URL.setClearButtonEnabled(True)
        self.EDIT_URL.setObjectName("EDIT_URL")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.EDIT_URL)
        self.EDIT_USER = QtWidgets.QLineEdit(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_USER.setFont(font)
        self.EDIT_USER.setClearButtonEnabled(True)
        self.EDIT_USER.setObjectName("EDIT_USER")
        self.formLayout.setWidget(1, QtWidgets.QFormLayout.FieldRole, self.EDIT_USER)
        self.EDIT_PASSWORD = QtWidgets.QLineEdit(self.GROUP_CRUCIBLE_SETTINGS)
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.EDIT_PASSWORD.setFont(font)
        self.EDIT_PASSWORD.setEchoMode(QtWidgets.QLineEdit.Password)
        self.EDIT_PASSWORD.setClearButtonEnabled(True)
        self.EDIT_PASSWORD.setObjectName("EDIT_PASSWORD")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.FieldRole, self.EDIT_PASSWORD)
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.formLayout.setItem(3, QtWidgets.QFormLayout.LabelRole, spacerItem1)
        self.gridLayout_2.addWidget(self.GROUP_CRUCIBLE_SETTINGS, 1, 1, 1, 1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem2)
        self.BTN_SAVE_SETTINGS = QtWidgets.QPushButton(CRUCIBLE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_SAVE_SETTINGS.setFont(font)
        self.BTN_SAVE_SETTINGS.setObjectName("BTN_SAVE_SETTINGS")
        self.horizontalLayout.addWidget(self.BTN_SAVE_SETTINGS)
        self.BTN_START = QtWidgets.QPushButton(CRUCIBLE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_START.setFont(font)
        self.BTN_START.setObjectName("BTN_START")
        self.horizontalLayout.addWidget(self.BTN_START)
        self.BTN_OPEN_SAVE_DIR = QtWidgets.QPushButton(CRUCIBLE_REPORT)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.BTN_OPEN_SAVE_DIR.setFont(font)
        self.BTN_OPEN_SAVE_DIR.setObjectName("BTN_OPEN_SAVE_DIR")
        self.horizontalLayout.addWidget(self.BTN_OPEN_SAVE_DIR)
        self.gridLayout_2.addLayout(self.horizontalLayout, 2, 0, 1, 2)
        self.LOG_WIDGET = LogWidget(CRUCIBLE_REPORT)
        self.LOG_WIDGET.setObjectName("LOG_WIDGET")
        self.gridLayout_2.addWidget(self.LOG_WIDGET, 3, 0, 1, 2)

        self.retranslateUi(CRUCIBLE_REPORT)
        QtCore.QMetaObject.connectSlotsByName(CRUCIBLE_REPORT)

    def retranslateUi(self, CRUCIBLE_REPORT):
        _translate = QtCore.QCoreApplication.translate
        CRUCIBLE_REPORT.setWindowTitle(_translate("CRUCIBLE_REPORT", "Review coverage report"))
        self.TITLE.setText(_translate("CRUCIBLE_REPORT", "Review coverage report"))
        self.GROUP_SCRIPT_SETTINGS.setTitle(_translate("CRUCIBLE_REPORT", "Script settings"))
        self.BTN_BROWSE_EMPLOYEE_MAPPING.setText(_translate("CRUCIBLE_REPORT", "browse"))
        self.LBL_EMPLOYEE_MAPPING.setText(_translate("CRUCIBLE_REPORT", "Employee mapping"))
        self.BTN_BROWSE_DOMAIN_MAPPING.setText(_translate("CRUCIBLE_REPORT", "browse"))
        self.LBL_DOMAIN_MAPPING.setText(_translate("CRUCIBLE_REPORT", "Domain mapping"))
        self.LBL_THREAD_COUNT.setText(_translate("CRUCIBLE_REPORT", "Thread count"))
        self.BTN_BROWSE_SAVE_REPORT_AS.setText(_translate("CRUCIBLE_REPORT", "browse"))
        self.LBL_SAVE_REPORT_AS.setText(_translate("CRUCIBLE_REPORT", "Save report as"))
        self.DATE_TO.setDisplayFormat(_translate("CRUCIBLE_REPORT", "yyyy/MM/dd"))
        self.LBL_DATE_TO.setText(_translate("CRUCIBLE_REPORT", "Date to"))
        self.DATE_FROM.setDisplayFormat(_translate("CRUCIBLE_REPORT", "yyyy/MM/dd"))
        self.LBL_DATE_FROM.setText(_translate("CRUCIBLE_REPORT", "Date from"))
        self.LBL_P4_CHANGES_FILE.setText(_translate("CRUCIBLE_REPORT", "p4 changes file"))
        self.BTN_BROWSE_P4_CHANGES_FILE.setText(_translate("CRUCIBLE_REPORT", "browse"))
        self.LBL_REPORT_VIEW.setText(_translate("CRUCIBLE_REPORT", "Report view"))
        self.GROUP_CRUCIBLE_SETTINGS.setTitle(_translate("CRUCIBLE_REPORT", "Crucible settings"))
        self.LBL_PASSWORD.setText(_translate("CRUCIBLE_REPORT", "Password"))
        self.LBL_USER.setText(_translate("CRUCIBLE_REPORT", "User"))
        self.LBL_URL.setText(_translate("CRUCIBLE_REPORT", "URL"))
        self.BTN_SAVE_SETTINGS.setText(_translate("CRUCIBLE_REPORT", "Save settings"))
        self.BTN_START.setText(_translate("CRUCIBLE_REPORT", "Start"))
        self.BTN_OPEN_SAVE_DIR.setText(_translate("CRUCIBLE_REPORT", "Open save dir"))
        #***************************************************************************************************************
        self.BTN_SAVE_SETTINGS.pressed.connect(self.saveSettingsPressed)
        self.BTN_BROWSE_P4_CHANGES_FILE.pressed.connect(self.browsePathToP4Pressed)
        self.BTN_BROWSE_SAVE_REPORT_AS.pressed.connect(self.browseSaveReportAsPressed)
        self.BTN_OPEN_SAVE_DIR.pressed.connect(self.openSaveDirPressed)
        self.BTN_START.pressed.connect(self.startPressed)
        self.BTN_BROWSE_DOMAIN_MAPPING.pressed.connect(self.browseDomainMapping)
        self.BTN_BROWSE_EMPLOYEE_MAPPING.pressed.connect(self.browseEmployeeMapping)


    def browsePathToP4Pressed(self):
        path = QtWidgets.QFileDialog.getOpenFileName(self, "", "", "*.txt")[0]
        if len(path):
            self.EDIT_P4_CHANGES_FILE.setText(path)


    def browseSaveReportAsPressed(self):
        x = QtWidgets.QFileDialog.getSaveFileName(self, "Save report as", "review_coverage_report", ".xlsx")
        if len(x[0]):
            path = x[0]

            if not x[1] in path:
                path += x[1]

            self.EDIT_SAVE_REPORTS_AS.setText(path)


    def browseDomainMapping(self):
        path = QtWidgets.QFileDialog.getOpenFileName(self, "Choose domain mapping file", "","*.ini", ".*")[0]
        if len(path):
            self.EDIT_DOMAIN_MAPPING.setText(path)


    def browseEmployeeMapping(self):
        path = QtWidgets.QFileDialog.getOpenFileName(self, "Choose employee mapping file", "","*.xlsx", ".*")[0]
        if len(path):
            self.EDIT_EMPLOYEE_MAPPING.setText(path)




    def openSaveDirPressed(self):
        if len(self.EDIT_SAVE_REPORTS_AS.text()):
            path = FS.dirName(self.EDIT_SAVE_REPORTS_AS.text())

            if FS.isDir(path):
                QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))


    def saveSettingsPressed(self):
        settings = {
            "p4changesFile": self.EDIT_P4_CHANGES_FILE.text(),
            "dateFrom":  self.DATE_FROM.textFromDateTime(self.DATE_FROM.dateTime()),
            "dateTo": self.DATE_TO.textFromDateTime(self.DATE_TO.dateTime()),
            "reportView": self.COMBO_REPORT_VIEW.currentText(),
            "saveReportAs": self.EDIT_SAVE_REPORTS_AS.text(),
            "threadCount": self.SPIN_THREAD_COUNT.text(),
            "url": self.EDIT_URL.text(),
            "user": self.EDIT_USER.text(),
            "password": self.EDIT_PASSWORD.text(),
            "domainMapping": self.EDIT_DOMAIN_MAPPING.text(),
            "employeeMapping": self.EDIT_EMPLOYEE_MAPPING.text(),
        }

        FS.checkCreateDir("data")
        ND.dict2json(settings, "data/user_settings_crucible_report.json")
        self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Currents settings have been saved", "green"))


    def loadSettings(self):
        if FS.isFile("data/user_settings_crucible_report.json"):
            settings = ND.json2dict("data/user_settings_crucible_report.json")
            self.EDIT_P4_CHANGES_FILE.setText(settings["p4changesFile"])
            self.DATE_FROM.setDateTime(self.DATE_FROM.dateTimeFromText(settings["dateFrom"]))
            self.DATE_TO.setDateTime(self.DATE_TO.dateTimeFromText(settings["dateTo"]))
            self.COMBO_REPORT_VIEW.setCurrentText(settings["reportView"])
            self.EDIT_SAVE_REPORTS_AS.setText(settings["saveReportAs"])
            self.SPIN_THREAD_COUNT.setValue(int(settings["threadCount"]))
            self.EDIT_URL.setText(settings["url"])
            self.EDIT_USER.setText(settings["user"])
            self.EDIT_PASSWORD.setText(settings["password"])
            self.EDIT_DOMAIN_MAPPING.setText(settings["domainMapping"])
            self.EDIT_EMPLOYEE_MAPPING.setText(settings["employeeMapping"])
            self.LOG_WIDGET.addSimpleMessageSignal.emit(colorStr("Presaved settings have been loaded", "green"))


    def startPressed(self):
        if self.preStartFieldsCheck():
            self.enableControls(False)

            self.reportObj.p4ChangeFile = self.EDIT_P4_CHANGES_FILE.text()
            self.reportObj.dateFrom = self.DATE_FROM.textFromDateTime(self.DATE_FROM.dateTime())
            self.reportObj.dateTo = self.DATE_TO.textFromDateTime(self.DATE_TO.dateTime())
            self.reportObj.url = self.EDIT_URL.text()
            self.reportObj.user = self.EDIT_USER.text()
            self.reportObj.password = self.EDIT_PASSWORD.text()

            self.reportObj.endCall = lambda : self.enableControls(True)

            Thread(target=self.reportObj.start).start()


    def preStartFieldsCheck(self):
        result = False
        checkList = list()
        checkList.append(self.checkWidget(self.EDIT_P4_CHANGES_FILE))
        checkList.append(self.checkWidget(self.EDIT_SAVE_REPORTS_AS))
        checkList.append(self.checkWidget(self.EDIT_URL))
        checkList.append(self.checkWidget(self.EDIT_USER))
        checkList.append(self.checkWidget(self.EDIT_PASSWORD))

        if not False in checkList:
            result = True

        return result


    def checkWidget(self, widget):
        result = False

        if len(widget.text()):
            widget.setStyleSheet("")
            result = True
        else:
            widget.setStyleSheet("background: rgb(255, 0, 0);")
            QtCore.QTimer.singleShot(1000, lambda : widget.setStyleSheet(""))

        return result


    def enableControls(self, boolValue):
        self.GROUP_SCRIPT_SETTINGS.setEnabled(boolValue)
        self.GROUP_CRUCIBLE_SETTINGS.setEnabled(boolValue)
        self.BTN_START.setEnabled(boolValue)