cd ${0%/*}
git config --global credential.helper store

if [ -d "tool_data" ]; then
	cd tool_data
	echo "Trying to update tool ..."
	git pull
	chmod +x report_generator
	./report_generator > log.txt &
	exit

else
	echo "Installing tool ..."
	git init
	git clone -b RG_bin_linux --depth=1 https://adc.luxoft.com/stash/scm/htoyota/htoyota-tools.git tool_data
	cd tool_data
	chmod +x report_generator
	./report_generator > log.txt &
	exit
fi
