from gui.ReportGenerator import ReportGenerator
import sys

from PyQt5 import QtWidgets, QtCore, QtGui

app = QtWidgets.QApplication(sys.argv)
app.setQuitOnLastWindowClosed(True)
ui = ReportGenerator()
ui.show()

sys.exit(app.exec_())