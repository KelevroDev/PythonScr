import xlsxwriter
from collections import OrderedDict


def allDataView(features, path):
    mtx = [["Feature id",
            "hbts files (path)",
            "hbts files (name)",
            "hbcm files (path)",
            "hbcm files (name)",
            "hbac files (path)",
            "hbac files (name)",
            "bin files (path)",
            "bin files (name)",
            "bin files (exec result)"]]

    for f in features:
        mtx.append([
            f.id,
            "\n".join([x["path"] for x in f.hbtsFiles]),
            "\n".join([x["name"] for x in f.hbtsFiles]),
            "\n".join([x["path"] for x in f.hbcmFiles]),
            "\n".join([x["name"] for x in f.hbcmFiles]),
            "\n".join([x["path"] for x in f.hbacFiles]),
            "\n".join([x["name"] for x in f.hbacFiles]),
            "\n".join([x["path"] for x in f.binFiles]),
            "\n".join([x["name"] for x in f.binFiles]),
            "\n".join([x["execResult"] for x in f.binFiles])
        ])


    xlsx = xlsxwriter.Workbook(path)

    formatNormal = xlsx.add_format({'valign': 'top',
                                    'text_wrap': True,
                                    'border': True,
                                    'font_size': 9})


    formatHeader = xlsx.add_format({'bold': True,
                                    'text_wrap': True,
                                    'align':'center',
                                    'valign': 'vcenter',
                                    'font_size': 9,
                                    'bg_color': '#C0C0C0',
                                    'border': True})


    xlsxSheet = xlsx.add_worksheet()
    xlsxSheet.autofilter("A1:J1")
    # xlsxSheet.set_column("A:A", 40)
    # xlsxSheet.set_column("B:B", 160)
    # xlsxSheet.set_column("C:C", 40)
    # xlsxSheet.set_column("D:D", 50)


    for i in range(len(mtx)):
        for j in range(len(mtx[i])):
            if i == 0:
                xlsxSheet.write(i, j, mtx[i][j], formatHeader)

            else:
                xlsxSheet.write(i, j, mtx[i][j], formatNormal)

    xlsxSheet.freeze_panes(1, 0)
    xlsx.close()



def statisticsView(features, path):
    aggElements = OrderedDict()

    for f in features:
        domain = (f.id.split("-"))[2]

        if not domain in aggElements.keys():
            aggElements[domain] = {"overall": 0, "covered": 0}

        aggElements[domain]["overall"] += 1

        if len(f.hbtsFiles):
            aggElements[domain]["covered"] += 1

    mtx = [["Domain Name",
            "Covered",
            "Overall"]]

    for x in aggElements.keys():
        mtx.append([x,
                    aggElements[x]["covered"],
                    aggElements[x]["overall"]
                    ])

    xlsx = xlsxwriter.Workbook(path)

    formatNormal = xlsx.add_format({'valign': 'top',
                                    'text_wrap': True,
                                    'border': True,
                                    'font_size': 9})


    formatHeader = xlsx.add_format({'bold': True,
                                    'text_wrap': True,
                                    'align':'center',
                                    'valign': 'vcenter',
                                    'font_size': 9,
                                    'bg_color': '#C0C0C0',
                                    'border': True})


    xlsxSheet = xlsx.add_worksheet()
    xlsxSheet.autofilter("A1:C1")


    for i in range(len(mtx)):
        for j in range(len(mtx[i])):
            if i == 0:
                xlsxSheet.write(i, j, mtx[i][j], formatHeader)

            else:
                xlsxSheet.write(i, j, mtx[i][j], formatNormal)

    xlsxSheet.freeze_panes(1, 0)
    xlsx.close()


def testExecView(features, path):
    mtx = [["Feature id",
            "bin files (name)",
            "bin files (path)",
            "bin files (exec result)"]]

    for f in features:
        mtx.append([
            f.id,
            "\n".join([x["name"] for x in f.binFiles]),
            "\n".join([x["path"] for x in f.binFiles]),
            "\n".join([x["execResult"] for x in f.binFiles])
        ])


    xlsx = xlsxwriter.Workbook(path)

    formatNormal = xlsx.add_format({'valign': 'top',
                                    'text_wrap': True,
                                    'border': True,
                                    'font_size': 9})


    formatHeader = xlsx.add_format({'bold': True,
                                    'text_wrap': True,
                                    'align':'center',
                                    'valign': 'vcenter',
                                    'font_size': 9,
                                    'bg_color': '#C0C0C0',
                                    'border': True})


    xlsxSheet = xlsx.add_worksheet()
    xlsxSheet.autofilter("A1:D1")
    xlsxSheet.set_column("A:A", 30)
    xlsxSheet.set_column("B:B", 50)
    xlsxSheet.set_column("C:C", 110)
    xlsxSheet.set_column("D:D", 60)


    for i in range(len(mtx)):
        for j in range(len(mtx[i])):
            if i == 0:
                xlsxSheet.write(i, j, mtx[i][j], formatHeader)

            else:
                xlsxSheet.write(i, j, mtx[i][j], formatNormal)

    xlsxSheet.freeze_panes(1, 0)
    xlsx.close()