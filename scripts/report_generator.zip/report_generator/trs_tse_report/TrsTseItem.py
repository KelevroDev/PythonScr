import re
import xml.etree.ElementTree as ET
from utility.FileSystem import FileSystem as FS
from utility.htmlCtx import *
from utility.other import traceErr

class TrsTseItem():
    def __init__(self, id, parent):
        self.id = id
        self.hbtsFiles = list()
        self.hbcmFiles = list()
        self.hbacFiles = list()
        self.binFiles = list()
        self.parent = parent

        self.logNormal = parent.logNormal


    def serialize(self):
        return {"trsFeature": {"id": self.id,
                               "hbtsFiles": list(self.hbtsFiles),
                               "hbcmFiles": list(self.hbcmFiles),
                               "hbacFiles": list(self.hbacFiles),
                               "binFiles": list(self.binFiles)}}

    @staticmethod
    def deserialize(data, parent):
        obj = TrsTseItem(data["id"], parent)
        obj.hbtsFiles = data["hbtsFiles"]
        obj.hbcmFiles = data["hbcmFiles"]
        obj.hbacFiles = data["hbacFiles"]
        obj.binFiles = data["binFiles"]

        return obj


    def getHbacFiles(self):
        self.logNormal(colorStr("Getting hbac for feature [%s]" % self.id, "blue"))
        self.hbacFiles.clear()

        for i in self.hbtsFiles:
            k = self._getHbacFilePath(i["path"])
            if k and k not in self.hbacFiles:
                self.hbacFiles.append(k)


    def getBinFiles(self):
        self.logNormal(colorStr("Getting binaries for feature [%s]" % self.id, "blue"))
        self.binFiles.clear()

        for i in self.hbacFiles:
            k = self._getBinName(i["path"])
            if k and k not in self.binFiles:
                self.binFiles.append(k)


    def getExecResults(self):
        self.logNormal(colorStr("Executing tests for feature [%s]" % self.id, "blue"))

        for bin in self.binFiles:
            if len(bin["path"]):
                bin["execResult"] = self._execTest(bin)


    def _getHbacFilePath(self, pathToHbtsFile):
        result = None
        folderPath = FS.dirName(pathToHbtsFile)
        jamfilePath = FS.join(folderPath, "Jamfile")

        if FS.isFile(jamfilePath):
            hbtsFileName = (pathToHbtsFile.split("/"))[-1]

            with open(jamfilePath, "r", errors = "ignore") as ctx:
                r = re.findall("%s[\w\s\#\.]+:[\s]+([\w]+)" % hbtsFileName, ctx.read())
                ctx.close()

                if len(r):
                    name = r[0] + ".hbac"
                    path = FS.join(folderPath, name)

                    if FS.isFile(path):
                        result = {"name": name, "path": path}

        return result


    def _getBinName(self, pathToHbacFile):
        result = None
        tree = ET.parse(pathToHbacFile)
        root = tree.getroot()
        processesTag = root.find(".//processes")

        name = processesTag.get("name")
        path = self._getBinPath(name)

        if processesTag:
            result = {"name": name, "path": path, "execResult": str()}

        return result


    def _getBinPath(self, binaryName):
        result = str()
        searchRes = FS.find(binaryName, self.parent.productsDir, FS.fullMatch)

        if len(searchRes):
            result = searchRes[0]

        return result


    def _execTest(self, binary):
        result = str()

        self.logNormal("Executing test [%s] from [%s]" % (binary["name"], binary["path"]))

        try:
            self.parent.scpClient.put(binary["path"], self.parent.targetBinDir)
            binPathOnTarget = FS.join(self.parent.targetBinDir, binary["name"])
            self._runCommand("chmod +x " + binPathOnTarget)
            command = binPathOnTarget

            if self.parent.preExecSettings:
                command = self.parent.preExecSettings + command

            result = self._runCommand(command)
            self._runCommand("rm -rf " + binPathOnTarget)

        except:
            self.logNormal("Error. Details: %s" % traceErr())


        return result


    def _runCommand(self, command):
        self.logNormal(colorStr(command))
        stdin, stdout, stderr = self.parent.paramikoClient.exec_command(command)
        output = (stdout.read().decode() + " " + stderr.read().decode()).strip()
        self.logNormal(highlightedStr(output, "orange"))

        return output