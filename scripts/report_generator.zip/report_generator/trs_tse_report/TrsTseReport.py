from trs_tse_report.TrsTseItem import TrsTseItem
from utility.FileSystem import FileSystem as FS
from utility.NiceData import NiceData as ND
from utility.Scp import SCPClient
from utility.htmlCtx import *
from utility.other import *
import xml.etree.ElementTree as ET
import re, paramiko


class TrsTseReport:
    def __init__(self, logOutput):
        self.trsListPath = str()
        self.trsFilter = str()
        self.clientDir = str()
        self.productsDir = str()
        self.targetIp = str()
        self.targetPort = str()
        self.targetUser = str()
        self.targetPassword = str()
        self.targetBinDir = str()
        self.features = list()
        self.preExecSettings = None
        self.paramikoClient = None
        self.scpClient = None

        self.getHbtsOption = False
        self.getHbcmOption = False
        self.getBinOption = False
        self.execTestsOption = False

        self.log = logOutput
        self.logNormal = self.log.addSimpleMessageSignal.emit
        self.logInc = self.log.incProgressSignal.emit

        self.endCall = None


    def start(self):
        self.logNormal(colorStr("Processing trs list".upper(), "purple"))
        self.processTrsList()
        self.saveDump()

        if self.getHbtsOption:
            self.logNormal(colorStr("Searching hbts files".upper(), "purple"))
            self.getHbtsFiles()
            self.saveDump()

        if self.getHbcmOption:
            self.logNormal(colorStr("Searching hbcm files".upper(), "purple"))

        if self.getBinOption:
            self.logNormal(colorStr("Searching hbac files".upper(), "purple"))
            self.getHbacFiles()
            self.logNormal(colorStr("Searching bin files".upper(), "purple"))
            self.getBinFiles()
            self.saveDump()

        if self.execTestsOption:
            self.logNormal(colorStr("Executing test on target".upper(), "purple"))
            self.execTestsOnTarget()
            self.saveDump()

        self.logNormal(colorStr("Process has been finished".upper(), "green"))

        if self.endCall:
            self.endCall()


    def continueProcess(self):
        pass


    def pingTarget(self):
        pass


    def saveDump(self):
        data = {"root": [f.serialize() for f in self.features]}
        FS.checkCreateDir("data")
        ND.dict2json(data, "data/dump_trs_tse_report.json")


    def processTrsList(self):
        with open(self.trsListPath, "r") as file:
            data = file.read().splitlines()
            file.close()
            self.features = [TrsTseItem(x, self) for x in data if x != "" and self.trsFilter in x]


    def getHbtsFiles(self):
        files = FS.find(".hbts", self.clientDir, FS.endsWith)
        self.logNormal(colorStr("%d hbts file were found in given directory" % len(files), "green"))
        occurrencesMap = self.parseHbtsFiles(files)

        matched = list()
        unmatched = list()

        self.log.setProgressMaxSignal.emit(len(self.features))
        self.log.setProgressValueSignal.emit(0)

        for i in self.features:
            self.logNormal(colorStr("Searching hbts files for feature [%s]" % i.id, "blue"))

            if i.id in occurrencesMap.keys():
                for occurrence in occurrencesMap[i.id]:
                    name = FS.fileName(occurrence)
                    path = occurrence
                    i.hbtsFiles.append({"name": name, "path": path})

                matched.append(i.id)

            self.logInc()

        for key in occurrencesMap.keys():
            if key not in matched:
                unmatched.append(key)

        # TBD unmathed hndling



    def parseHbtsFiles(self, files):
        map = dict()

        for i in range(len(files)):
            curFilePath = files[i]
            searchResults = list()
            tree = ET.parse(curFilePath)
            root = tree.getroot()
            cutDescriptionTag = root[0].find(".//cutDescription")

            if cutDescriptionTag:
                searchResults += re.findall("(TRS-MEUCY17[\w\-]+)", cutDescriptionTag.get("description"))

            for i in root[0].findall(".//testOrigins"):
                searchResults += re.findall("(TRS-MEUCY17[\w\-]+)", i.get("id"))

            searchResults = list(set(searchResults))

            for trs in searchResults:
                if trs in map.keys():
                    map[trs].append(curFilePath)
                else:
                    map[trs] = [curFilePath]

        return map



    def getHbacFiles(self):
        self.log.setProgressMaxSignal.emit(len(self.features))
        self.log.setProgressValueSignal.emit(0)

        for f in self.features:
            f.getHbacFiles()
            self.logInc()


    def getBinFiles(self):
        self.log.setProgressMaxSignal.emit(len(self.features))
        self.log.setProgressValueSignal.emit(0)

        for f in self.features:
            f.getBinFiles()
            self.logInc()


    def execTestsOnTarget(self):
        self.paramikoClient = paramiko.SSHClient()
        self.paramikoClient.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        connected = False

        try:
            self.paramikoClient.connect(self.targetIp, int(self.targetPort), self.targetUser, self.targetPassword)
            connected = True
        except:
            self.logNormal(colorStr("Cannot connect via ssh. Detials: %s" % traceErr(), "red"))

        if connected:
            self.scpClient = SCPClient(self.paramikoClient.get_transport())

            self.log.setProgressMaxSignal.emit(len(self.features))
            self.log.setProgressValueSignal.emit(0)

            for f in self.features:
                f.getExecResults()
                self.logInc()

            self.scpClient.close()
            self.paramikoClient.close()

